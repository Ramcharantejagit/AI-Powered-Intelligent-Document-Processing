"""
FormIQ - web application for the FUNSD Intelligent Document Processing project.

Reuses the existing project directly:
  * code/idp_utils.py           -> OCR, preprocessing, inference, entity grouping, key-value linking
  * models/best_model/          -> trained Graph-BiLSTM-CRF (loaded once, never retrained here)
  * data/raw/dataset/testing_data -> real FUNSD test forms offered as samples (with gold labels for scoring)
  * models/model_evaluation_results/model_comparison_test.csv -> real model metrics shown in the UI

Run:  python app.py        (creates instance/idp_app.db and the default admin on first start)
"""
import csv
import functools
import json
import os
import re
import secrets
import sqlite3
import sys
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone

from flask import (Flask, abort, flash, g, jsonify, redirect, render_template, request, send_file,
                   session, url_for)
from PIL import Image, ImageDraw, UnidentifiedImageError
from werkzeug.security import check_password_hash, generate_password_hash

# ----------------------------------------------------------------------------------------------
# Paths / configuration
# ----------------------------------------------------------------------------------------------
APP_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(APP_DIR)
CODE_DIR = os.path.join(PROJECT_DIR, "code")
BEST_MODEL_DIR = os.path.join(PROJECT_DIR, "models", "best_model")
RESULTS_CSV = os.path.join(PROJECT_DIR, "models", "model_evaluation_results", "model_comparison_test.csv")
SAMPLE_DIR = os.path.join(PROJECT_DIR, "data", "raw", "dataset", "testing_data")
INSTANCE_DIR = os.environ.get("IDP_INSTANCE_DIR", os.path.join(APP_DIR, "instance"))
UPLOAD_DIR = os.path.join(INSTANCE_DIR, "uploads")
DB_PATH = os.path.join(INSTANCE_DIR, "idp_app.db")
os.makedirs(UPLOAD_DIR, exist_ok=True)

sys.path.insert(0, CODE_DIR)
import idp_utils as U  # noqa: E402  (project module)

ALLOWED_IMAGE_EXT = {"png", "jpg", "jpeg", "tif", "tiff", "bmp"}
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,59}$")
SAMPLE_ID_RE = re.compile(r"^[0-9A-Za-z_]{1,40}$")
LABEL_COLORS = {"header": (230, 126, 34), "question": (41, 128, 185), "answer": (39, 174, 96)}


def _secret_key():
    env = os.environ.get("IDP_SECRET_KEY")
    if env:
        return env
    path = os.path.join(INSTANCE_DIR, "secret_key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
        os.chmod(path, 0o600)
    return open(path).read().strip()


app = Flask(__name__)
app.config.update(
    SECRET_KEY=_secret_key(),
    MAX_CONTENT_LENGTH=10 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("IDP_SECURE_COOKIES", "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=2),
)


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# ----------------------------------------------------------------------------------------------
# Database
# ----------------------------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    username TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('user','admin')),
    status TEXT NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED')),
    created_at TEXT NOT NULL,
    reviewed_at TEXT,
    last_login TEXT
);
CREATE TABLE IF NOT EXISTS records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    doc_name TEXT NOT NULL,
    source TEXT NOT NULL,
    word_source TEXT NOT NULL,
    model_name TEXT NOT NULL,
    n_words INTEGER, n_header INTEGER, n_question INTEGER, n_answer INTEGER, n_pairs INTEGER,
    avg_confidence REAL, low_conf_count INTEGER,
    model_ms REAL, total_ms REAL,
    eval_word_accuracy REAL, eval_entity_f1 REAL,
    image_file TEXT NOT NULL, annotated_file TEXT NOT NULL, result_file TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS activities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    actor TEXT,
    action TEXT NOT NULL,
    detail TEXT,
    ip TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_records_user ON records(user_id);
CREATE INDEX IF NOT EXISTS idx_act_user ON activities(user_id);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """Create tables and the default admin account (admin / Admin@123) if missing."""
    con = sqlite3.connect(DB_PATH)
    con.executescript(SCHEMA)
    if not con.execute("SELECT 1 FROM users WHERE username = 'admin'").fetchone():
        con.execute("INSERT INTO users (name, username, password_hash, role, status, created_at, reviewed_at) "
                    "VALUES (?, 'admin', ?, 'admin', 'APPROVED', ?, ?)",
                    ("Administrator", generate_password_hash("Admin@123"), now_iso(), now_iso()))
    con.commit()
    con.close()


def log_activity(action, detail="", user_id=None, actor=None):
    u = g.get("user")
    get_db().execute("INSERT INTO activities (user_id, actor, action, detail, ip, created_at) VALUES (?,?,?,?,?,?)",
                     (user_id if user_id is not None else (u["id"] if u else None),
                      actor or (u["email"] or u["username"] if u else None),
                      action, detail[:500], request.remote_addr, now_iso()))
    get_db().commit()


# ----------------------------------------------------------------------------------------------
# Security: session user loading, CSRF, role/approval decorators, headers, login throttling
# ----------------------------------------------------------------------------------------------
@app.before_request
def load_user_and_csrf():
    g.user = None
    uid = session.get("uid")
    if uid is not None:
        row = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        # Approval is re-checked on every request: rejected/deleted users lose access immediately.
        if row is None or row["status"] != "APPROVED" or row["role"] != session.get("role"):
            session.clear()
        else:
            g.user = row
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(32)
    if request.method == "POST":
        token = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
        if not token or not secrets.compare_digest(token, session["csrf"]):
            abort(400, description="Invalid or missing CSRF token.")


@app.context_processor
def inject_globals():
    return {"csrf_token": session.get("csrf", ""), "current_user": g.get("user"),
            "best_model_name": BEST_INFO["best_model"].replace("_", "-")}


@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    if g.get("user") is not None:
        resp.headers["Cache-Control"] = "no-store"
    return resp


def login_required(role):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*a, **kw):
            if g.user is None:
                if request.path.startswith("/api/"):
                    return jsonify(error="authentication required"), 401
                flash("Please log in to continue.", "warning")
                return redirect(url_for("admin_login" if role == "admin" else "login", next=request.path))
            if role != "any" and g.user["role"] != role:
                abort(403)
            return fn(*a, **kw)
        return wrapper
    return deco


_failed = {}
_failed_lock = threading.Lock()


def throttled(key):
    with _failed_lock:
        hits = [t for t in _failed.get(key, []) if t > time.time() - 600]
        _failed[key] = hits
        return len(hits) >= 5


def register_failure(key):
    with _failed_lock:
        _failed.setdefault(key, []).append(time.time())


def safe_next(target):
    return target if target and target.startswith("/") and not target.startswith("//") else None


def start_session(user):
    session.clear()                      # prevent session fixation
    session.permanent = True
    session["uid"], session["role"] = user["id"], user["role"]
    session["csrf"] = secrets.token_urlsafe(32)
    get_db().execute("UPDATE users SET last_login = ? WHERE id = ?", (now_iso(), user["id"]))
    get_db().commit()
    g.user = user


# ----------------------------------------------------------------------------------------------
# IDP model (loaded once) and processing
# ----------------------------------------------------------------------------------------------
_bundle, _model_lock, _infer_lock = None, threading.Lock(), threading.Lock()


def get_bundle():
    global _bundle
    with _model_lock:
        if _bundle is None:
            import torch
            torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
            _bundle = U.load_model_bundle(BEST_MODEL_DIR)
        return _bundle


def load_model_results():
    if not os.path.exists(RESULTS_CSV):
        return []
    with open(RESULTS_CSV) as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        out.append({"model": r[""], "system": r["system"], "entity_f1": float(r["entity_f1"]),
                    "word_accuracy": float(r["word_accuracy"]), "word_f1_macro": float(r["word_f1_macro"]),
                    "roc_auc": float(r["roc_auc_ovr_macro"]), "ms_per_doc": float(r["ms_per_doc"]),
                    "val_entity_f1": float(r["val_entity_f1"])})
    return out


MODEL_RESULTS = load_model_results()
BEST_INFO = json.load(open(os.path.join(BEST_MODEL_DIR, "best_model_info.json")))
SAMPLE_IDS = sorted(f[:-4] for f in os.listdir(os.path.join(SAMPLE_DIR, "images")) if f.endswith(".png"))


def validate_words_json(raw):
    """Validate an uploaded words file: [{"text": str, "box": [x0,y0,x1,y1]}, ...]."""
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeDecodeError):
        raise ValueError("Words file is not valid JSON.")
    if isinstance(data, dict) and "form" in data:            # also accept a FUNSD annotation file
        data = [{"text": w["text"], "box": w["box"]} for e in data["form"] for w in e.get("words", [])]
    if not isinstance(data, list) or not data or len(data) > 5000:
        raise ValueError("Words file must be a non-empty list (max 5000 words).")
    words = []
    for w in data:
        if not (isinstance(w, dict) and isinstance(w.get("text"), str) and isinstance(w.get("box"), list)
                and len(w["box"]) == 4 and all(isinstance(v, (int, float)) for v in w["box"])):
            raise ValueError('Each word needs "text" (string) and "box" [x0, y0, x1, y1].')
        words.append({"text": w["text"][:100], "box": [int(v) for v in w["box"]]})
    return words


def save_upload_image(file_storage, dest):
    ext = file_storage.filename.rsplit(".", 1)[-1].lower() if "." in file_storage.filename else ""
    if ext not in ALLOWED_IMAGE_EXT:
        raise ValueError("Unsupported image type. Use PNG, JPG, TIFF or BMP.")
    try:
        img = Image.open(file_storage.stream)
        img.verify()
        file_storage.stream.seek(0)
        img = Image.open(file_storage.stream)
        if img.width * img.height > 40_000_000:
            raise ValueError("Image is too large.")
        img.convert("L").save(dest, "PNG")
    except (UnidentifiedImageError, OSError):
        raise ValueError("The uploaded file is not a readable image.")


def draw_annotations(image_path, entities, dest):
    img = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(img, "RGBA")
    for e in entities:
        c = LABEL_COLORS[e["label"]]
        draw.rectangle(e["box"], outline=c + (255,), fill=c + (40,), width=2)
    img.save(dest, "PNG")


def run_pipeline(user_id, image_path, doc_name, source, words=None, word_source="tesseract", gold_doc=None):
    """Ingestion -> (OCR) -> preprocessing -> best-model classification -> extraction -> validation -> storage."""
    t0 = time.perf_counter()
    if words is not None:
        doc = U.document_from_words(words, image_path, doc_id=doc_name)
    else:
        doc = U.ocr_document(image_path, doc_id=doc_name)
    if not doc["words"]:
        raise ValueError("No text could be read from this image.")
    bundle = get_bundle()
    with _infer_lock:                      # one inference at a time (CPU-bound, shared model)
        result = U.process_document(bundle, doc)
    total_ms = 1000 * (time.perf_counter() - t0)
    eval_acc = eval_f1 = None
    if gold_doc is not None and [w["text"] for w in gold_doc["words"]] == [w["text"] for w in doc["words"]]:
        pred = [w["predicted_tag"] for w in result["words"]]
        eval_acc = sum(U.bio_to_class(a) == U.bio_to_class(b) for a, b in zip(gold_doc["bio"], pred)) / len(pred)
        eval_f1 = U.entity_scores([gold_doc["bio"]], [pred])["ALL"]["f1"]
        result["evaluation_against_gold"] = {"word_accuracy": eval_acc, "entity_f1": eval_f1}
    stem = uuid.uuid4().hex
    user_dir = os.path.join(UPLOAD_DIR, str(user_id))
    os.makedirs(user_dir, exist_ok=True)
    annotated = os.path.join(user_dir, stem + "_annotated.png")
    draw_annotations(image_path, result["entities"], annotated)
    result_file = os.path.join(user_dir, stem + "_result.json")
    result.update(word_source=word_source, total_time_sec=round(total_ms / 1000, 4))
    with open(result_file, "w") as f:
        json.dump(result, f, indent=2)
    ents = result["entities"]
    cnt = {k: sum(e["label"] == k for e in ents) for k in ("header", "question", "answer")}
    conf = [w["confidence"] for w in result["words"]]
    cur = get_db().execute(
        """INSERT INTO records (user_id, doc_name, source, word_source, model_name, n_words, n_header, n_question,
           n_answer, n_pairs, avg_confidence, low_conf_count, model_ms, total_ms, eval_word_accuracy, eval_entity_f1,
           image_file, annotated_file, result_file, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (user_id, doc_name, source, word_source, result["model"], result["n_words"], cnt["header"], cnt["question"],
         cnt["answer"], len(result["key_value_pairs"]), sum(conf) / len(conf), len(result["low_confidence_entities"]),
         1000 * result["processing_time_sec"], total_ms, eval_acc, eval_f1,
         os.path.relpath(image_path, INSTANCE_DIR), os.path.relpath(annotated, INSTANCE_DIR),
         os.path.relpath(result_file, INSTANCE_DIR), now_iso()))
    get_db().commit()
    return cur.lastrowid


# ----------------------------------------------------------------------------------------------
# Public pages
# ----------------------------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", results=MODEL_RESULTS, best=BEST_INFO)


@app.route("/about")
def about():
    return render_template("about.html", results=MODEL_RESULTS, best=BEST_INFO)


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("home_for_user"))
    form = {"name": "", "email": ""}
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        pw, pw2 = request.form.get("password", ""), request.form.get("confirm_password", "")
        form = {"name": name, "email": email}
        errors = []
        if not NAME_RE.match(name):
            errors.append("Name must be 2-60 letters (spaces, . ' - allowed).")
        if not EMAIL_RE.match(email) or len(email) > 120:
            errors.append("Enter a valid email address.")
        if len(pw) < 8 or len(pw) > 128 or not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
            errors.append("Password must be 8-128 characters and contain letters and numbers.")
        if pw != pw2:
            errors.append("Passwords do not match.")
        if not errors and get_db().execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            errors.append("An account with this email already exists.")
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("register.html", form=form), 400
        # Public registration can only ever create role='user' with status='PENDING'.
        cur = get_db().execute("INSERT INTO users (name, email, password_hash, role, status, created_at) "
                               "VALUES (?, ?, ?, 'user', 'PENDING', ?)",
                               (name, email, generate_password_hash(pw), now_iso()))
        get_db().commit()
        log_activity("register", "New account awaiting approval", user_id=cur.lastrowid, actor=email)
        return render_template("pending.html", name=name, email=email, just_registered=True)
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("home_for_user"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        key = f"user:{request.remote_addr}"
        if throttled(key):
            flash("Too many failed attempts. Try again in 10 minutes.", "danger")
            return render_template("login.html", email=email), 429
        row = get_db().execute("SELECT * FROM users WHERE email = ? AND role = 'user'", (email,)).fetchone()
        if row is None or not check_password_hash(row["password_hash"], pw):
            register_failure(key)
            log_activity("login_failed", "Invalid credentials", user_id=row["id"] if row else None, actor=email)
            flash("Invalid email or password.", "danger")
            return render_template("login.html", email=email), 401
        if row["status"] == "PENDING":
            log_activity("login_blocked", "Account pending approval", user_id=row["id"], actor=email)
            return render_template("pending.html", name=row["name"], email=email, just_registered=False), 403
        if row["status"] == "REJECTED":
            log_activity("login_blocked", "Account rejected", user_id=row["id"], actor=email)
            flash("Your registration was rejected by the administrator. You cannot log in.", "danger")
            return render_template("login.html", email=email), 403
        start_session(row)
        log_activity("login", "User login")
        return redirect(safe_next(request.args.get("next")) or url_for("dashboard"))
    return render_template("login.html", email="")


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if g.user:
        return redirect(url_for("home_for_user"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        pw = request.form.get("password", "")
        key = f"admin:{request.remote_addr}"
        if throttled(key):
            flash("Too many failed attempts. Try again in 10 minutes.", "danger")
            return render_template("admin_login.html"), 429
        row = get_db().execute("SELECT * FROM users WHERE username = ? AND role = 'admin'", (username,)).fetchone()
        if row is None or not check_password_hash(row["password_hash"], pw):
            register_failure(key)
            log_activity("admin_login_failed", "Invalid admin credentials", actor=username[:60])
            flash("Invalid admin username or password.", "danger")
            return render_template("admin_login.html"), 401
        start_session(row)
        log_activity("admin_login", "Admin login")
        return redirect(safe_next(request.args.get("next")) or url_for("admin_dashboard"))
    return render_template("admin_login.html")


@app.route("/logout", methods=["POST"])
@login_required("any")
def logout():
    log_activity("logout", "Signed out")
    session.clear()
    flash("You have been signed out.", "info")
    return redirect(url_for("index"))


@app.route("/home")
@login_required("any")
def home_for_user():
    return redirect(url_for("admin_dashboard" if g.user["role"] == "admin" else "dashboard"))


# ----------------------------------------------------------------------------------------------
# User area
# ----------------------------------------------------------------------------------------------
def user_stats(user_id):
    db = get_db()
    s = db.execute("""SELECT COUNT(*) n, COALESCE(SUM(n_words),0) words, COALESCE(SUM(n_header),0) h,
                      COALESCE(SUM(n_question),0) q, COALESCE(SUM(n_answer),0) a, COALESCE(SUM(n_pairs),0) pairs,
                      AVG(avg_confidence) conf, AVG(total_ms) ms, AVG(eval_entity_f1) f1, COUNT(eval_entity_f1) n_eval
                      FROM records WHERE user_id = ?""", (user_id,)).fetchone()
    recent = db.execute("SELECT * FROM records WHERE user_id = ? ORDER BY id DESC LIMIT 15", (user_id,)).fetchall()
    return s, list(reversed(recent))


@app.route("/dashboard")
@login_required("user")
def dashboard():
    stats, recent = user_stats(g.user["id"])
    chart = {"labels": [f"#{r['id']}" for r in recent],
             "conf": [round(r["avg_confidence"], 4) for r in recent],
             "ms": [round(r["total_ms"]) for r in recent],
             "entities": [stats["h"], stats["q"], stats["a"]],
             "models": [m["model"] for m in MODEL_RESULTS], "model_f1": [m["entity_f1"] for m in MODEL_RESULTS],
             "model_system": [m["system"] for m in MODEL_RESULTS]}
    return render_template("dashboard.html", stats=stats, recent=list(reversed(recent))[:5], chart=chart,
                           samples=SAMPLE_IDS, best=BEST_INFO)


@app.route("/process", methods=["POST"])
@login_required("user")
def process():
    mode = request.form.get("mode")
    user_dir = os.path.join(UPLOAD_DIR, str(g.user["id"]))
    os.makedirs(user_dir, exist_ok=True)
    try:
        if mode == "sample":
            sid = request.form.get("sample_id", "")
            if not SAMPLE_ID_RE.match(sid) or sid not in SAMPLE_IDS:
                raise ValueError("Unknown sample form.")
            word_source = request.form.get("word_source", "dataset")
            if word_source not in ("dataset", "tesseract"):
                raise ValueError("Invalid word source.")
            src_img = os.path.join(SAMPLE_DIR, "images", sid + ".png")
            dest = os.path.join(user_dir, uuid.uuid4().hex + ".png")
            Image.open(src_img).save(dest, "PNG")
            gold = U.load_funsd_document(os.path.join(SAMPLE_DIR, "annotations", sid + ".json"), src_img)
            words = None
            if word_source == "dataset":   # dataset OCR words with every label removed
                ann = json.load(open(os.path.join(SAMPLE_DIR, "annotations", sid + ".json")))
                words = [{"text": w["text"], "box": w["box"]} for e in ann["form"] for w in e["words"]]
            rid = run_pipeline(g.user["id"], dest, f"FUNSD test form {sid}", "sample", words, word_source, gold)
        elif mode == "upload":
            f = request.files.get("image")
            if f is None or not f.filename:
                raise ValueError("Choose an image to upload.")
            dest = os.path.join(user_dir, uuid.uuid4().hex + ".png")
            save_upload_image(f, dest)
            wf = request.files.get("words")
            words, word_source = None, "tesseract"
            if wf is not None and wf.filename:
                words, word_source = validate_words_json(wf.read().decode("utf-8", "replace")), "uploaded_json"
            name = re.sub(r"[^A-Za-z0-9._ -]", "_", os.path.basename(f.filename))[:80]
            try:
                rid = run_pipeline(g.user["id"], dest, name, "upload", words, word_source)
            except Exception:
                os.remove(dest)
                raise
        else:
            raise ValueError("Invalid request.")
    except ValueError as e:
        flash(str(e), "danger")
        return redirect(url_for("dashboard"))
    log_activity("process_document", f"Record #{rid} ({mode})")
    flash("Document processed successfully.", "success")
    return redirect(url_for("record_detail", rid=rid))


def get_record_or_404(rid):
    """Owners see their own records; admins see all. Anything else -> 404 (no existence leak)."""
    row = get_db().execute("SELECT r.*, u.name AS owner_name, u.email AS owner_email FROM records r "
                           "JOIN users u ON u.id = r.user_id WHERE r.id = ?", (rid,)).fetchone()
    if row is None or (g.user["role"] != "admin" and row["user_id"] != g.user["id"]):
        abort(404)
    return row


@app.route("/records/<int:rid>")
@login_required("any")
def record_detail(rid):
    rec = get_record_or_404(rid)
    result = json.load(open(os.path.join(INSTANCE_DIR, rec["result_file"])))
    return render_template("record.html", rec=rec, result=result)


@app.route("/records/<int:rid>/image/<kind>")
@login_required("any")
def record_image(rid, kind):
    rec = get_record_or_404(rid)
    if kind not in ("original", "annotated"):
        abort(404)
    return send_file(os.path.join(INSTANCE_DIR, rec["image_file" if kind == "original" else "annotated_file"]),
                     mimetype="image/png")


@app.route("/records/<int:rid>/json")
@login_required("any")
def record_json(rid):
    rec = get_record_or_404(rid)
    log_activity("download_json", f"Record #{rid}")
    return send_file(os.path.join(INSTANCE_DIR, rec["result_file"]), mimetype="application/json",
                     as_attachment=True, download_name=f"record_{rid}_extraction.json")


@app.route("/samples/<sid>.png")
@login_required("any")
def sample_image(sid):
    if sid not in SAMPLE_IDS:
        abort(404)
    img = Image.open(os.path.join(SAMPLE_DIR, "images", sid + ".png"))
    img.thumbnail((380, 500))
    path = os.path.join(INSTANCE_DIR, "thumb_cache")
    os.makedirs(path, exist_ok=True)
    out = os.path.join(path, sid + ".png")
    if not os.path.exists(out):
        img.save(out)
    return send_file(out, mimetype="image/png")


@app.route("/history")
@login_required("user")
def history():
    recs = get_db().execute("SELECT * FROM records WHERE user_id = ? ORDER BY id DESC", (g.user["id"],)).fetchall()
    acts = get_db().execute("SELECT * FROM activities WHERE user_id = ? ORDER BY id DESC LIMIT 100",
                            (g.user["id"],)).fetchall()
    return render_template("history.html", records=recs, activities=acts)


@app.route("/profile", methods=["GET", "POST"])
@login_required("any")
def profile():
    if request.method == "POST":
        cur_pw, new_pw, new_pw2 = (request.form.get(k, "") for k in ("current_password", "new_password", "confirm_password"))
        if not check_password_hash(g.user["password_hash"], cur_pw):
            flash("Current password is incorrect.", "danger")
        elif len(new_pw) < 8 or len(new_pw) > 128 or not re.search(r"[A-Za-z]", new_pw) or not re.search(r"\d", new_pw):
            flash("New password must be 8-128 characters with letters and numbers.", "danger")
        elif new_pw != new_pw2:
            flash("New passwords do not match.", "danger")
        else:
            get_db().execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(new_pw), g.user["id"]))
            get_db().commit()
            log_activity("change_password", "Password changed")
            flash("Password updated.", "success")
        return redirect(url_for("profile"))
    n_rec = get_db().execute("SELECT COUNT(*) FROM records WHERE user_id = ?", (g.user["id"],)).fetchone()[0]
    return render_template("profile.html", n_records=n_rec)


# ----------------------------------------------------------------------------------------------
# Admin area
# ----------------------------------------------------------------------------------------------
@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    db = get_db()
    status = {r["status"]: r["n"] for r in db.execute(
        "SELECT status, COUNT(*) n FROM users WHERE role = 'user' GROUP BY status")}
    totals = db.execute("""SELECT COUNT(*) n, COALESCE(SUM(n_header+n_question+n_answer),0) ents,
                           AVG(avg_confidence) conf, AVG(eval_entity_f1) f1, COUNT(eval_entity_f1) n_eval
                           FROM records""").fetchone()
    per_day = db.execute("SELECT substr(created_at,1,10) d, COUNT(*) n FROM records GROUP BY d ORDER BY d DESC LIMIT 14").fetchall()
    per_user = db.execute("""SELECT u.name, COUNT(r.id) n FROM users u LEFT JOIN records r ON r.user_id = u.id
                             WHERE u.role = 'user' AND u.status = 'APPROVED' GROUP BY u.id ORDER BY n DESC LIMIT 10""").fetchall()
    pending = db.execute("SELECT * FROM users WHERE role = 'user' AND status = 'PENDING' ORDER BY id").fetchall()
    acts = db.execute("SELECT * FROM activities ORDER BY id DESC LIMIT 12").fetchall()
    chart = {"status": [status.get(k, 0) for k in ("PENDING", "APPROVED", "REJECTED")],
             "days": [r["d"] for r in reversed(per_day)], "day_counts": [r["n"] for r in reversed(per_day)],
             "users": [r["name"] for r in per_user], "user_counts": [r["n"] for r in per_user]}
    return render_template("admin_dashboard.html", status=status, totals=totals, pending=pending, acts=acts, chart=chart)


@app.route("/admin/users")
@login_required("admin")
def admin_users():
    q = request.args.get("status", "")
    sql = """SELECT u.*, (SELECT COUNT(*) FROM records r WHERE r.user_id = u.id) n_records FROM users u
             WHERE u.role = 'user'"""
    args = ()
    if q in ("PENDING", "APPROVED", "REJECTED"):
        sql += " AND u.status = ?"
        args = (q,)
    users = get_db().execute(sql + " ORDER BY u.id DESC", args).fetchall()
    return render_template("admin_users.html", users=users, status_filter=q)


@app.route("/admin/users/<int:uid>/<action>", methods=["POST"])
@login_required("admin")
def admin_user_action(uid, action):
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE id = ? AND role = 'user'", (uid,)).fetchone()
    if row is None or action not in ("approve", "reject", "delete"):
        abort(404)
    if action == "delete":
        recs = db.execute("SELECT image_file, annotated_file, result_file FROM records WHERE user_id = ?", (uid,)).fetchall()
        for r in recs:
            for k in r.keys():
                p = os.path.join(INSTANCE_DIR, r[k])
                if os.path.exists(p):
                    os.remove(p)
        db.execute("DELETE FROM users WHERE id = ?", (uid,))
        msg = f"Deleted user {row['email']}"
    else:
        new = "APPROVED" if action == "approve" else "REJECTED"
        db.execute("UPDATE users SET status = ?, reviewed_at = ? WHERE id = ?", (new, now_iso(), uid))
        msg = f"{new.title()} user {row['email']}"
    db.commit()
    log_activity(f"admin_{action}_user", msg)
    flash(msg + ".", "success")
    return redirect(safe_next(request.form.get("next")) or url_for("admin_users"))


@app.route("/admin/records")
@login_required("admin")
def admin_records():
    uid = request.args.get("user_id", type=int)
    sql = "SELECT r.*, u.name AS owner_name, u.email AS owner_email FROM records r JOIN users u ON u.id = r.user_id"
    recs = get_db().execute(sql + (" WHERE r.user_id = ?" if uid else "") + " ORDER BY r.id DESC LIMIT 500",
                            (uid,) if uid else ()).fetchall()
    return render_template("admin_records.html", records=recs, user_id=uid)


@app.route("/admin/activity")
@login_required("admin")
def admin_activity():
    uid = request.args.get("user_id", type=int)
    sql = "SELECT * FROM activities" + (" WHERE user_id = ?" if uid else "") + " ORDER BY id DESC LIMIT 500"
    acts = get_db().execute(sql, (uid,) if uid else ()).fetchall()
    return render_template("admin_activity.html", acts=acts, user_id=uid)


# ----------------------------------------------------------------------------------------------
# JSON API (same auth rules) - used by nothing internally but handy for integration
# ----------------------------------------------------------------------------------------------
@app.route("/api/records")
@login_required("any")
def api_records():
    if g.user["role"] == "admin":
        rows = get_db().execute("SELECT * FROM records ORDER BY id DESC LIMIT 500").fetchall()
    else:
        rows = get_db().execute("SELECT * FROM records WHERE user_id = ? ORDER BY id DESC", (g.user["id"],)).fetchall()
    keep = ["id", "user_id", "doc_name", "source", "word_source", "model_name", "n_words", "n_header", "n_question",
            "n_answer", "n_pairs", "avg_confidence", "total_ms", "eval_word_accuracy", "eval_entity_f1", "created_at"]
    return jsonify([{k: r[k] for k in keep} for r in rows])


@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(413)
def http_error(e):
    code = getattr(e, "code", 500)
    msg = {403: "You do not have permission to access this page.", 404: "Page not found.",
           413: "File too large (max 10 MB)."}.get(code, getattr(e, "description", "Bad request."))
    if request.path.startswith("/api/"):
        return jsonify(error=msg), code
    return render_template("error.html", code=code, message=msg), code


@app.template_filter("pct")
def pct(v):
    return "-" if v is None else f"{100 * v:.1f}%"


@app.cli.command("init-db")
def init_db_command():
    """flask --app app init-db : create tables and the default admin (idempotent)."""
    init_db()
    print(f"Database ready at {DB_PATH} (admin / Admin@123)")


init_db()

if __name__ == "__main__":
    get_bundle()  # warm up the model before serving
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)), debug=False)
