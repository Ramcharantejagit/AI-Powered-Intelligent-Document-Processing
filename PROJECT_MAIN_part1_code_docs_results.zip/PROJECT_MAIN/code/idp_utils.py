"""
idp_utils.py
Shared Intelligent Document Processing (IDP) pipeline for the FUNSD form-understanding task.

Used by BOTH notebooks so that prediction applies exactly the same preprocessing as training:
    01_Data_Preprocessing_and_Model_Training.ipynb
    02_Best_Model_Prediction.ipynb

Pipeline stages (following the modular IDP architecture of the reference paper):
    ingestion -> OCR / word extraction -> preprocessing (cleaning, reading order)
    -> feature engineering (text + layout + visual) -> classification (semantic entity labelling)
    -> extraction (entity grouping, key-value pairing) -> validation (confidence) -> storage (JSON)
"""
import json
import math
import os
import re
import string
import time
from collections import Counter

import numpy as np
from PIL import Image

# --------------------------------------------------------------------------------------
# Label definitions
# --------------------------------------------------------------------------------------
ENTITY_TYPES = ["HEADER", "QUESTION", "ANSWER"]
BIO_LABELS = ["O", "B-HEADER", "I-HEADER", "B-QUESTION", "I-QUESTION", "B-ANSWER", "I-ANSWER"]
LABEL2ID = {l: i for i, l in enumerate(BIO_LABELS)}
ID2LABEL = {i: l for l, i in LABEL2ID.items()}
CLASS_NAMES = ["other", "header", "question", "answer"]          # word-level semantic classes
FUNSD2TYPE = {"header": "HEADER", "question": "QUESTION", "answer": "ANSWER"}


def bio_to_class(tag):
    """Map a BIO tag to its word-level semantic class name."""
    return "other" if tag == "O" else tag.split("-", 1)[1].lower()


# --------------------------------------------------------------------------------------
# Ingestion
# --------------------------------------------------------------------------------------
def load_funsd_document(json_path, image_path):
    """Load one FUNSD annotation + image into a document dict (words in reading order).
    Cleaning: words with empty / whitespace-only text are dropped, boxes are clipped to the page."""
    with open(json_path, encoding="utf-8") as f:
        ann = json.load(f)
    with Image.open(image_path) as im:
        width, height = im.size
    words = []
    for ent in ann["form"]:
        for w in ent["words"]:
            text = w["text"].strip()
            if not text:
                continue
            words.append({"text": text, "box": clip_box(w["box"], width, height),
                          "label": ent["label"], "entity_id": ent["id"]})
    doc = {"doc_id": os.path.splitext(os.path.basename(json_path))[0], "image_path": image_path,
           "width": width, "height": height, "words": words}
    return finalize_document(doc)


def load_funsd_split(split_dir):
    """Load every document of a FUNSD split folder (training_data / testing_data)."""
    ann_dir, img_dir = os.path.join(split_dir, "annotations"), os.path.join(split_dir, "images")
    docs = []
    for fn in sorted(os.listdir(ann_dir)):
        if fn.endswith(".json"):
            docs.append(load_funsd_document(os.path.join(ann_dir, fn),
                                            os.path.join(img_dir, fn.replace(".json", ".png"))))
    return docs


def document_from_words(words, image_path, doc_id="new_document"):
    """Build an (unlabelled) document from externally supplied words: [{'text':..,'box':[x0,y0,x1,y1]}]."""
    with Image.open(image_path) as im:
        width, height = im.size
    clean = []
    for w in words:
        t = str(w["text"]).strip()
        if t:
            clean.append({"text": t, "box": clip_box(w["box"], width, height),
                          "label": w.get("label"), "entity_id": w.get("entity_id")})
    return finalize_document({"doc_id": doc_id, "image_path": image_path, "width": width,
                              "height": height, "words": clean})


def ocr_document(image_path, min_conf=30, doc_id=None):
    """OCR stage: extract words + boxes from a scanned form with Tesseract."""
    import pytesseract
    img = Image.open(image_path).convert("L")
    data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
    words = []
    for i, txt in enumerate(data["text"]):
        try:
            conf = float(data["conf"][i])
        except ValueError:
            conf = -1
        if txt.strip() and conf >= min_conf:
            x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
            words.append({"text": txt.strip(), "box": [x, y, x + w, y + h]})
    return document_from_words(words, image_path, doc_id or os.path.splitext(os.path.basename(image_path))[0])


def clip_box(box, width, height):
    x0, y0, x1, y1 = [int(v) for v in box]
    x0, x1 = sorted((max(0, min(x0, width - 1)), max(0, min(x1, width - 1))))
    y0, y1 = sorted((max(0, min(y0, height - 1)), max(0, min(y1, height - 1))))
    return [x0, y0, max(x1, x0 + 1), max(y1, y0 + 1)]


# --------------------------------------------------------------------------------------
# Preprocessing: reading order, BIO tags, visual statistics
# --------------------------------------------------------------------------------------
def sort_reading_order(words):
    """Group words into text lines (vertical overlap) and sort top->bottom, left->right.
    Uses only geometry, never entity ids, so no label information leaks into the order."""
    if not words:
        return words
    heights = [w["box"][3] - w["box"][1] for w in words]
    med_h = float(np.median(heights))
    order = sorted(range(len(words)), key=lambda i: (words[i]["box"][1] + words[i]["box"][3]) / 2)
    lines = []  # each: dict(ymin, ymax, idx list)
    for i in order:
        x0, y0, x1, y1 = words[i]["box"]
        h = max(1, min(y1 - y0, 2 * med_h))
        yc = (y0 + y1) / 2
        best, best_ov = None, 0.0
        for ln in lines[-6:]:
            ov = min(yc + h / 2, ln["ymax"]) - max(yc - h / 2, ln["ymin"])
            ratio = ov / min(h, ln["ymax"] - ln["ymin"])
            if ratio > 0.5 and ratio > best_ov:
                best, best_ov = ln, ratio
        if best is None:
            lines.append({"ymin": yc - h / 2, "ymax": yc + h / 2, "idx": [i]})
        else:
            best["idx"].append(i)
    lines.sort(key=lambda ln: ln["ymin"])
    out = []
    for li, ln in enumerate(lines):
        idx = sorted(ln["idx"], key=lambda i: words[i]["box"][0])
        for pi, i in enumerate(idx):
            w = dict(words[i])
            w.update(line_id=li, pos_in_line=pi, line_len=len(idx))
            out.append(w)
    return out


def make_bio_tags(words):
    """Gold BIO tags in reading order: B- starts an entity segment, I- continues the same entity."""
    tags, prev_ent = [], None
    for w in words:
        if w.get("label") is None:
            return None
        if w["label"] == "other":
            tags.append("O")
            prev_ent = None
            continue
        t = FUNSD2TYPE[w["label"]]
        tags.append(("I-" if w["entity_id"] == prev_ent else "B-") + t)
        prev_ent = w["entity_id"]
    return tags


CROP_H, CROP_W = 24, 80


def add_visual_stats(doc):
    """Computer-vision stage: per-word ink density / darkness + a normalised grey-scale crop."""
    img = np.asarray(Image.open(doc["image_path"]).convert("L"), dtype=np.uint8)
    crops = np.zeros((len(doc["words"]), CROP_H, CROP_W), dtype=np.uint8)
    for k, w in enumerate(doc["words"]):
        x0, y0, x1, y1 = w["box"]
        patch = img[y0:y1 + 1, x0:x1 + 1]
        if patch.size == 0:
            patch = np.full((1, 1), 255, np.uint8)
        dark = 255 - patch.astype(np.float32)
        w["ink_density"] = float((patch < 128).mean())
        w["ink_mean"] = float(dark.mean() / 255.0)
        crops[k] = 255 - np.asarray(Image.fromarray(patch).resize((CROP_W, CROP_H), Image.BILINEAR))
    doc["crops"] = crops
    return doc


def finalize_document(doc):
    doc["words"] = sort_reading_order(doc["words"])
    doc["bio"] = make_bio_tags(doc["words"]) if doc["words"] else []
    add_visual_stats(doc)
    add_geometric_context(doc)
    return doc


def add_geometric_context(doc):
    """Line-level and neighbour-level geometric context used by every model."""
    W, H = doc["width"], doc["height"]
    words = doc["words"]
    if not words:
        doc["n_lines"] = 0
        return doc
    med_h = float(np.median([w["box"][3] - w["box"][1] for w in words]))
    n_lines = words[-1]["line_id"] + 1
    line_text, line_box = {}, {}
    for w in words:
        line_text.setdefault(w["line_id"], []).append(w["text"])
        b = line_box.setdefault(w["line_id"], list(w["box"]))
        b[0], b[1] = min(b[0], w["box"][0]), min(b[1], w["box"][1])
        b[2], b[3] = max(b[2], w["box"][2]), max(b[3], w["box"][3])
    for i, w in enumerate(words):
        lid = w["line_id"]
        prev = words[i - 1] if i > 0 and words[i - 1]["line_id"] == lid else None
        nxt = words[i + 1] if i + 1 < len(words) and words[i + 1]["line_id"] == lid else None
        w["gap_prev"] = (w["box"][0] - prev["box"][2]) / W if prev else -0.05
        w["gap_next"] = (nxt["box"][0] - w["box"][2]) / W if nxt else -0.05
        toks = line_text[lid]
        p = w["pos_in_line"]
        w["colon_before"] = int(any(t.endswith(":") for t in toks[:p]))
        w["colon_after"] = int(any(t.endswith(":") for t in toks[p + 1:]))
        w["line_ends_colon"] = int(toks[-1].endswith(":"))
        above = line_box.get(lid - 1)
        below = line_box.get(lid + 1)
        w["dist_above"] = (line_box[lid][1] - above[3]) / H if above else 0.1
        w["dist_below"] = (below[1] - line_box[lid][3]) / H if below else 0.1
        w["h_rel"] = (w["box"][3] - w["box"][1]) / max(med_h, 1)
    doc["n_lines"] = n_lines
    return doc


# --------------------------------------------------------------------------------------
# Feature engineering
# --------------------------------------------------------------------------------------
PUNCT = set(string.punctuation)


def norm_token(t):
    return re.sub(r"\d", "0", t.lower())


def word_shape(t):
    s = re.sub(r"[A-Z]", "X", t)
    s = re.sub(r"[a-z]", "x", s)
    s = re.sub(r"\d", "d", s)
    return re.sub(r"(.)\1{2,}", r"\1\1", s)[:8]


NUM_FEATURES = ["x0", "y0", "x1", "y1", "xc", "yc", "w", "h", "h_rel", "log_aspect", "ink_density",
                "ink_mean", "gap_prev", "gap_next", "line_pos", "pos_in_line", "log_line_len",
                "is_first_in_line", "is_last_in_line", "colon_before", "colon_after", "line_ends_colon",
                "dist_above", "dist_below", "ends_colon", "is_upper", "is_title", "has_digit",
                "is_punct", "log_len"]


def numeric_features(doc, i):
    w = doc["words"][i]
    W, H = doc["width"], doc["height"]
    x0, y0, x1, y1 = w["box"]
    t = w["text"]
    return {
        "x0": x0 / W, "y0": y0 / H, "x1": x1 / W, "y1": y1 / H,
        "xc": (x0 + x1) / 2 / W, "yc": (y0 + y1) / 2 / H, "w": (x1 - x0) / W, "h": (y1 - y0) / H,
        "h_rel": w["h_rel"], "log_aspect": math.log((x1 - x0 + 1) / (y1 - y0 + 1)),
        "ink_density": w["ink_density"], "ink_mean": w["ink_mean"],
        "gap_prev": w["gap_prev"], "gap_next": w["gap_next"],
        "line_pos": w["line_id"] / max(doc["n_lines"], 1),
        "pos_in_line": w["pos_in_line"] / max(w["line_len"], 1),
        "log_line_len": math.log1p(w["line_len"]),
        "is_first_in_line": float(w["pos_in_line"] == 0),
        "is_last_in_line": float(w["pos_in_line"] == w["line_len"] - 1),
        "colon_before": w["colon_before"], "colon_after": w["colon_after"],
        "line_ends_colon": w["line_ends_colon"], "dist_above": w["dist_above"], "dist_below": w["dist_below"],
        "ends_colon": float(t.endswith(":")), "is_upper": float(t.isupper()), "is_title": float(t.istitle()),
        "has_digit": float(any(c.isdigit() for c in t)), "is_punct": float(all(c in PUNCT for c in t)),
        "log_len": math.log1p(len(t)),
    }


def _token_feats(t, prefix):
    return {f"{prefix}word": norm_token(t), f"{prefix}shape": word_shape(t),
            f"{prefix}ends_colon": float(t.endswith(":")), f"{prefix}is_upper": float(t.isupper())}


def classical_features(doc):
    """Hand-crafted feature dicts per word (text + layout + visual + context window ±2),
    used by the existing-system models (LR, SVM, RF, CRF)."""
    words, feats = doc["words"], []
    n = len(words)
    for i, w in enumerate(words):
        t = w["text"]
        f = {"bias": 1.0, "word": norm_token(t), "shape": word_shape(t),
             "prefix3": norm_token(t)[:3], "suffix3": norm_token(t)[-3:]}
        f.update(numeric_features(doc, i))
        for off in (-2, -1, 1, 2):
            j = i + off
            if 0 <= j < n:
                f.update(_token_feats(words[j]["text"], f"{off:+d}:"))
                f[f"{off:+d}:same_line"] = float(words[j]["line_id"] == w["line_id"])
            else:
                f[f"{off:+d}:BOUNDARY"] = 1.0
        feats.append(f)
    return feats


# --------------------------------------------------------------------------------------
# Neural preprocessing object (fit on training split only -> no leakage)
# --------------------------------------------------------------------------------------
class NeuralPreprocessor:
    """Builds word/char vocabularies and a numeric-feature scaler from TRAINING documents only,
    then converts any document into model-ready arrays."""
    PAD, UNK = 0, 1
    MAX_CHARS = 16

    def __init__(self, min_word_freq=2):
        self.min_word_freq = min_word_freq

    def fit(self, docs):
        wc, cc = Counter(), Counter()
        for d in docs:
            for w in d["words"]:
                wc[norm_token(w["text"])] += 1
                cc.update(w["text"])
        self.word2id = {"<pad>": 0, "<unk>": 1}
        for tok, c in wc.most_common():
            if c >= self.min_word_freq:
                self.word2id[tok] = len(self.word2id)
        self.char2id = {"<pad>": 0, "<unk>": 1}
        for ch, c in cc.most_common():
            if c >= 2:
                self.char2id[ch] = len(self.char2id)
        X = np.concatenate([self._raw_numeric(d) for d in docs])
        self.num_mean, self.num_std = X.mean(0), X.std(0) + 1e-6
        return self

    def _raw_numeric(self, doc):
        return np.array([[numeric_features(doc, i)[k] for k in NUM_FEATURES]
                         for i in range(len(doc["words"]))], dtype=np.float32).reshape(-1, len(NUM_FEATURES))

    def transform(self, doc):
        words = doc["words"]
        n = len(words)
        wid = np.array([self.word2id.get(norm_token(w["text"]), self.UNK) for w in words], dtype=np.int64)
        cid = np.zeros((n, self.MAX_CHARS), dtype=np.int64)
        for i, w in enumerate(words):
            for j, ch in enumerate(w["text"][: self.MAX_CHARS]):
                cid[i, j] = self.char2id.get(ch, self.UNK)
        num = (self._raw_numeric(doc) - self.num_mean) / self.num_std
        W, H = doc["width"], doc["height"]
        bbox = np.array([[int(1000 * b[0] / W), int(1000 * b[1] / H), int(1000 * b[2] / W), int(1000 * b[3] / H)]
                         for b in (w["box"] for w in words)], dtype=np.int64).reshape(-1, 4).clip(0, 1000)
        labels = np.array([LABEL2ID[t] for t in doc["bio"]], dtype=np.int64) if doc.get("bio") else None
        return {"word_ids": wid, "char_ids": cid, "num": num.astype(np.float32), "bbox": bbox,
                "crops": doc["crops"], "labels": labels, "n": n}

    @property
    def vocab_size(self):
        return len(self.word2id)

    @property
    def n_chars(self):
        return len(self.char2id)


# --------------------------------------------------------------------------------------
# Neural models (PyTorch)
# --------------------------------------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F


def collate(items, device="cpu"):
    """Pad a list of transformed documents into a batch."""
    B, T = len(items), max(it["n"] for it in items)
    C = items[0]["char_ids"].shape[1]
    nf = items[0]["num"].shape[1]
    out = {"word_ids": torch.zeros(B, T, dtype=torch.long), "char_ids": torch.zeros(B, T, C, dtype=torch.long),
           "num": torch.zeros(B, T, nf), "bbox": torch.zeros(B, T, 4, dtype=torch.long),
           "crops": torch.zeros(B, T, CROP_H, CROP_W), "mask": torch.zeros(B, T, dtype=torch.bool),
           "labels": torch.zeros(B, T, dtype=torch.long)}
    for b, it in enumerate(items):
        n = it["n"]
        out["word_ids"][b, :n] = torch.from_numpy(it["word_ids"])
        out["char_ids"][b, :n] = torch.from_numpy(it["char_ids"])
        out["num"][b, :n] = torch.from_numpy(it["num"])
        out["bbox"][b, :n] = torch.from_numpy(it["bbox"])
        out["crops"][b, :n] = torch.from_numpy(it["crops"].astype(np.float32) / 255.0)
        out["mask"][b, :n] = True
        if it["labels"] is not None:
            out["labels"][b, :n] = torch.from_numpy(it["labels"])
    return {k: v.to(device) for k, v in out.items()}


class TokenEncoder(nn.Module):
    """Multimodal word representation: word embedding + char-CNN (text), scaled layout features,
    and a small CNN over the word image crop (vision)."""

    def __init__(self, vocab_size, n_chars, n_num, d_word=64, d_char=24, char_filters=48, d_num=48,
                 d_vis=32, word_dropout=0.1, dropout=0.2):
        super().__init__()
        self.word_dropout = word_dropout
        self.word_emb = nn.Embedding(vocab_size, d_word, padding_idx=0)
        self.char_emb = nn.Embedding(n_chars, d_char, padding_idx=0)
        self.char_cnn = nn.Conv1d(d_char, char_filters, kernel_size=3, padding=1)
        self.num_mlp = nn.Sequential(nn.Linear(n_num, d_num), nn.ReLU(), nn.Linear(d_num, d_num))
        self.vis_dim = d_vis
        self.vis_cnn = nn.Sequential(
            nn.Conv2d(1, 8, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(8, 16, 3, stride=2, padding=1), nn.ReLU(),
            nn.Conv2d(16, d_vis, 3, padding=1), nn.ReLU(), nn.AdaptiveAvgPool2d(1))
        self.drop = nn.Dropout(dropout)
        self.out_dim = d_word + char_filters + d_num + d_vis

    def forward(self, batch):
        wid = batch["word_ids"]
        if self.training and self.word_dropout > 0:
            drop = (torch.rand_like(wid, dtype=torch.float) < self.word_dropout) & (wid > 1)
            wid = wid.masked_fill(drop, 1)
        B, T, C = batch["char_ids"].shape
        ce = self.char_emb(batch["char_ids"].view(B * T, C)).transpose(1, 2)
        ch = F.relu(self.char_cnn(ce)).max(dim=2).values.view(B, T, -1)
        m = batch["mask"]
        vis = ch.new_zeros(B, T, self.vis_dim)
        vis[m] = self.vis_cnn(batch["crops"][m].unsqueeze(1)).flatten(1)   # CNN only on real words
        x = torch.cat([self.word_emb(wid), ch, self.num_mlp(batch["num"]), vis], dim=-1)
        return self.drop(x)


class CRF(nn.Module):
    """Linear-chain CRF with NLL, Viterbi decoding and forward-backward marginals."""

    def __init__(self, n_tags):
        super().__init__()
        self.n = n_tags
        self.trans = nn.Parameter(torch.zeros(n_tags, n_tags))
        self.start = nn.Parameter(torch.zeros(n_tags))
        self.end = nn.Parameter(torch.zeros(n_tags))

    def _forward_alg(self, em, mask):
        alpha = self.start + em[:, 0]
        alphas = [alpha]
        for t in range(1, em.size(1)):
            nxt = torch.logsumexp(alpha.unsqueeze(2) + self.trans + em[:, t].unsqueeze(1), dim=1)
            alpha = torch.where(mask[:, t].unsqueeze(1), nxt, alpha)
            alphas.append(alpha)
        return alphas, torch.logsumexp(alpha + self.end, dim=1)

    def nll(self, em, tags, mask):
        B, T, _ = em.shape
        score = self.start[tags[:, 0]] + em[:, 0].gather(1, tags[:, :1]).squeeze(1)
        for t in range(1, T):
            s = self.trans[tags[:, t - 1], tags[:, t]] + em[:, t].gather(1, tags[:, t:t + 1]).squeeze(1)
            score = score + s * mask[:, t]
        last = tags.gather(1, (mask.sum(1) - 1).unsqueeze(1)).squeeze(1)
        score = score + self.end[last]
        _, logz = self._forward_alg(em, mask)
        return (logz - score).sum() / mask.sum()   # per-token normalised NLL

    def marginals(self, em, mask):
        alphas, logz = self._forward_alg(em, mask)
        B, T, K = em.shape
        beta = self.end.expand(B, K)
        betas = [None] * T
        lengths = mask.sum(1)
        for t in range(T - 1, -1, -1):
            if t < T - 1:
                nb = torch.logsumexp(self.trans.unsqueeze(0) + (em[:, t + 1] + beta).unsqueeze(1), dim=2)
                beta = torch.where(mask[:, t + 1].unsqueeze(1), nb, self.end.expand(B, K))
            betas[t] = beta
        out = torch.stack([alphas[t] + betas[t] for t in range(T)], dim=1) - logz.view(B, 1, 1)
        return out.exp()

    def viterbi(self, em, mask):
        B, T, K = em.shape
        score = self.start + em[:, 0]
        bps = []
        for t in range(1, T):
            s = score.unsqueeze(2) + self.trans
            best, idx = s.max(dim=1)
            nxt = best + em[:, t]
            score = torch.where(mask[:, t].unsqueeze(1), nxt, score)
            bps.append(torch.where(mask[:, t].unsqueeze(1), idx, torch.arange(K).expand(B, K).to(idx)))
        score = score + self.end
        last = score.argmax(1)
        path = [last]
        for bp in reversed(bps):
            last = bp.gather(1, last.unsqueeze(1)).squeeze(1)
            path.append(last)
        return torch.stack(path[::-1], dim=1)


class CRFTagger(nn.Module):
    """Common head: subclasses produce emission scores; a linear-chain CRF over reading order
    gives the training loss (NLL), Viterbi-decoded BIO tags and per-word marginal probabilities."""

    def loss(self, batch):
        return self.crf.nll(self.emissions(batch), batch["labels"], batch["mask"])

    @torch.no_grad()
    def predict(self, batch):
        em = self.emissions(batch)
        return self.crf.viterbi(em, batch["mask"]), self.crf.marginals(em, batch["mask"])


class BiLSTMCRF(CRFTagger):
    """Proposed model 1: multimodal token encoder -> 2-layer BiLSTM over reading order -> CRF."""

    def __init__(self, vocab_size, n_chars, n_num, n_tags=7, hidden=128, layers=2, dropout=0.3, **enc_kw):
        super().__init__()
        self.enc = TokenEncoder(vocab_size, n_chars, n_num, **enc_kw)
        self.lstm = nn.LSTM(self.enc.out_dim, hidden, num_layers=layers, bidirectional=True,
                            batch_first=True, dropout=dropout)
        self.drop = nn.Dropout(dropout)
        self.proj = nn.Linear(2 * hidden, n_tags)
        self.crf = CRF(n_tags)

    def emissions(self, batch):
        x = self.enc(batch)
        lengths = batch["mask"].sum(1).cpu()
        packed = nn.utils.rnn.pack_padded_sequence(x, lengths, batch_first=True, enforce_sorted=False)
        h, _ = self.lstm(packed)
        h, _ = nn.utils.rnn.pad_packed_sequence(h, batch_first=True, total_length=x.size(1))
        return self.proj(self.drop(h))



class EdgeGATLayer(nn.Module):
    """Graph attention over k spatial neighbours with relative-geometry edge features."""

    def __init__(self, d, heads=4, d_edge=16, dropout=0.2):
        super().__init__()
        self.h, self.dk = heads, d // heads
        self.q, self.k, self.v = nn.Linear(d, d), nn.Linear(d, d), nn.Linear(d, d)
        self.edge_k = nn.Linear(d_edge, d)
        self.edge_bias = nn.Linear(d_edge, heads)
        self.o = nn.Linear(d, d)
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.ff = nn.Sequential(nn.Linear(d, 2 * d), nn.GELU(), nn.Dropout(dropout), nn.Linear(2 * d, d))
        self.drop = nn.Dropout(dropout)

    def forward(self, x, nbr, nbr_mask, e):
        B, T, D = x.shape
        K = nbr.size(2)
        q = self.q(x).view(B, T, 1, self.h, self.dk)
        idx = nbr.view(B, T * K, 1).expand(-1, -1, D)
        kx = torch.gather(self.k(x), 1, idx).view(B, T, K, D) + self.edge_k(e)
        vx = torch.gather(self.v(x), 1, idx).view(B, T, K, D) + self.edge_k(e)
        kx, vx = kx.view(B, T, K, self.h, self.dk), vx.view(B, T, K, self.h, self.dk)
        att = (q * kx).sum(-1) / math.sqrt(self.dk) + self.edge_bias(e)
        att = att.masked_fill(~nbr_mask.unsqueeze(-1), -1e9).softmax(dim=2)
        h = (self.drop(att).unsqueeze(-1) * vx).sum(2).reshape(B, T, D)
        x = self.ln1(x + self.drop(self.o(h)))
        return self.ln2(x + self.drop(self.ff(x)))


def build_knn_graph(bbox, mask, k=12):
    """k nearest neighbours (box-centre distance, incl. self) + edge features from 0-1000 boxes."""
    b = bbox.float() / 1000.0
    ctr = torch.stack([(b[..., 0] + b[..., 2]) / 2, (b[..., 1] + b[..., 3]) / 2], -1)
    d = torch.cdist(ctr, ctr)
    d = d.masked_fill(~mask.unsqueeze(1), 1e4)
    k = min(k, bbox.size(1))
    dist, nbr = d.topk(k, dim=2, largest=False)
    nbr_mask = (dist < 1e3) & mask.unsqueeze(2)
    B, T, _ = b.shape
    nb = torch.gather(b.unsqueeze(1).expand(B, T, T, 4), 2, nbr.unsqueeze(-1).expand(-1, -1, -1, 4))
    src = b.unsqueeze(2).expand_as(nb)
    w_s, h_s = (src[..., 2] - src[..., 0]).clamp(min=1e-3), (src[..., 3] - src[..., 1]).clamp(min=1e-3)
    w_n, h_n = (nb[..., 2] - nb[..., 0]).clamp(min=1e-3), (nb[..., 3] - nb[..., 1]).clamp(min=1e-3)
    dx = (nb[..., 0] + nb[..., 2] - src[..., 0] - src[..., 2]) / 2
    dy = (nb[..., 1] + nb[..., 3] - src[..., 1] - src[..., 3]) / 2
    e = torch.stack([dx * 10, dy * 10, dist.clamp(max=10) * 10, torch.log(w_n / w_s), torch.log(h_n / h_s),
                     (nb[..., 0] - src[..., 2]) * 10, (src[..., 0] - nb[..., 2]) * 10,
                     (nb[..., 1] - src[..., 3]) * 10], -1)
    return nbr, nbr_mask, e


class LayoutGAT(CRFTagger):
    """Proposed model 2: multimodal token encoder -> k-NN layout graph -> 3 edge-aware GAT layers -> CRF."""

    def __init__(self, vocab_size, n_chars, n_num, n_tags=7, hidden=128, layers=3, heads=4, k=12,
                 dropout=0.2, **enc_kw):
        super().__init__()
        self.k = k
        self.enc = TokenEncoder(vocab_size, n_chars, n_num, **enc_kw)
        self.inp = nn.Linear(self.enc.out_dim, hidden)
        self.edge_mlp = nn.Sequential(nn.Linear(8, 16), nn.ReLU(), nn.Linear(16, 16))
        self.layers = nn.ModuleList([EdgeGATLayer(hidden, heads, 16, dropout) for _ in range(layers)])
        self.out = nn.Linear(hidden, n_tags)
        self.crf = CRF(n_tags)

    def emissions(self, batch):
        x = self.inp(self.enc(batch))
        nbr, nmask, e = build_knn_graph(batch["bbox"], batch["mask"], self.k)
        e = self.edge_mlp(e)
        for layer in self.layers:
            x = layer(x, nbr, nmask, e)
        return self.out(x)



class BiasedSelfAttentionLayer(nn.Module):
    """Pre-LayerNorm Transformer encoder layer whose attention logits receive an additive bias."""

    def __init__(self, d, heads, ff, dropout):
        super().__init__()
        self.h, self.dk = heads, d // heads
        self.qkv, self.o = nn.Linear(d, 3 * d), nn.Linear(d, d)
        self.ln1, self.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.ff = nn.Sequential(nn.Linear(d, ff), nn.GELU(), nn.Dropout(dropout), nn.Linear(ff, d))
        self.drop = nn.Dropout(dropout)
        self.p = dropout

    def forward(self, x, bias):
        B, T, D = x.shape
        q, k, v = self.qkv(self.ln1(x)).view(B, T, 3, self.h, self.dk).permute(2, 0, 3, 1, 4)
        a = F.scaled_dot_product_attention(q, k, v, attn_mask=bias, dropout_p=self.p if self.training else 0.0)
        x = x + self.drop(self.o(a.transpose(1, 2).reshape(B, T, D)))
        return x + self.drop(self.ff(self.ln2(x)))


def fourier_bbox(bbox, n_freq=8):
    """Continuous sinusoidal encoding of normalised box coordinates (x0, y0, x1, y1)."""
    b = bbox.float() / 1000.0
    freqs = (2.0 ** torch.arange(n_freq, device=b.device).float()) * math.pi
    ang = b.unsqueeze(-1) * freqs
    return torch.cat([ang.sin(), ang.cos()], -1).flatten(-2)


class LayoutTransformer(CRFTagger):
    """Proposed model 3: spatially-aware Transformer (LayoutLMv2-style idea, trained from scratch).
    Token = multimodal embedding + continuous 2-D box encoding; every self-attention layer receives a
    learned per-head bias computed from pairwise relative geometry (dx, dy, distance, reading-order
    offset, same-line flag), which injects layout locality without memorising absolute positions. CRF decoding on top."""

    def __init__(self, vocab_size, n_chars, n_num, n_tags=7, hidden=128, layers=3, heads=4, ff=256,
                 dropout=0.2, **enc_kw):
        super().__init__()
        self.heads = heads
        self.enc = TokenEncoder(vocab_size, n_chars, n_num, **enc_kw)
        self.inp = nn.Linear(self.enc.out_dim, hidden)
        self.box_proj = nn.Linear(4 * 2 * 8, hidden)
        self.rel_bias = nn.Sequential(nn.Linear(6, 32), nn.GELU(), nn.Linear(32, heads * layers))
        self.ln = nn.LayerNorm(hidden)
        self.drop = nn.Dropout(dropout)
        self.layers = nn.ModuleList([BiasedSelfAttentionLayer(hidden, heads, ff, dropout) for _ in range(layers)])
        self.final_ln = nn.LayerNorm(hidden)
        self.out = nn.Linear(hidden, n_tags)
        self.crf = CRF(n_tags)

    def _relative_bias(self, bbox, mask):
        b = bbox.float() / 1000.0
        cx, cy = (b[..., 0] + b[..., 2]) / 2, (b[..., 1] + b[..., 3]) / 2
        h = (b[..., 3] - b[..., 1]).clamp(min=1e-3)
        dx = cx.unsqueeze(1) - cx.unsqueeze(2)
        dy = cy.unsqueeze(1) - cy.unsqueeze(2)
        T = b.size(1)
        ro = torch.arange(T, device=b.device).float()
        dro = (ro.view(1, 1, T) - ro.view(1, T, 1)).expand_as(dx)
        same_line = (dy.abs() < 0.5 * torch.minimum(h.unsqueeze(1), h.unsqueeze(2))).float()
        feats = torch.stack([dx * 5, dy * 5, torch.sqrt(dx ** 2 + dy ** 2) * 5,
                             torch.sign(dro) * torch.log1p(dro.abs()) / 3, same_line, (dx > 0).float()], -1)
        bias = self.rel_bias(feats)                       # [B, T, T, heads*layers]
        bias = bias.masked_fill(~mask.view(-1, 1, T, 1), -1e4)
        return bias.permute(0, 3, 1, 2)                   # [B, heads*layers, T, T]

    def emissions(self, batch):
        bb, mask = batch["bbox"], batch["mask"]
        x = self.inp(self.enc(batch)) + self.box_proj(fourier_bbox(bb))
        x = self.drop(self.ln(x))
        bias = self._relative_bias(bb, mask)
        for i, layer in enumerate(self.layers):
            x = layer(x, bias[:, i * self.heads:(i + 1) * self.heads])
        return self.out(self.final_ln(x))



class GraphBiLSTMCRF(CRFTagger):
    """Proposed model 4 (hybrid): multimodal token encoder -> 2 edge-aware GAT layers (2-D spatial
    context) -> BiLSTM (1-D reading-order context) -> CRF."""

    def __init__(self, vocab_size, n_chars, n_num, n_tags=7, hidden=128, gat_layers=2, heads=4, k=12,
                 lstm_hidden=128, dropout=0.3, **enc_kw):
        super().__init__()
        self.k = k
        self.enc = TokenEncoder(vocab_size, n_chars, n_num, **enc_kw)
        self.inp = nn.Linear(self.enc.out_dim, hidden)
        self.edge_mlp = nn.Sequential(nn.Linear(8, 16), nn.ReLU(), nn.Linear(16, 16))
        self.gat = nn.ModuleList([EdgeGATLayer(hidden, heads, 16, 0.2) for _ in range(gat_layers)])
        self.lstm = nn.LSTM(hidden + self.enc.out_dim, lstm_hidden, num_layers=1, bidirectional=True,
                            batch_first=True)
        self.drop = nn.Dropout(dropout)
        self.proj = nn.Linear(2 * lstm_hidden, n_tags)
        self.crf = CRF(n_tags)

    def emissions(self, batch):
        e0 = self.enc(batch)
        x = self.inp(e0)
        nbr, nmask, e = build_knn_graph(batch["bbox"], batch["mask"], self.k)
        e = self.edge_mlp(e)
        for layer in self.gat:
            x = layer(x, nbr, nmask, e)
        x = torch.cat([x, e0], -1)
        lengths = batch["mask"].sum(1).cpu()
        packed = nn.utils.rnn.pack_padded_sequence(x, lengths, batch_first=True, enforce_sorted=False)
        h, _ = self.lstm(packed)
        h, _ = nn.utils.rnn.pad_packed_sequence(h, batch_first=True, total_length=x.size(1))
        return self.proj(self.drop(h))


NEURAL_MODELS = {"BiLSTMCRF": BiLSTMCRF, "LayoutGAT": LayoutGAT, "LayoutTransformer": LayoutTransformer,
                 "GraphBiLSTMCRF": GraphBiLSTMCRF}


def build_neural_model(arch, prep, **hparams):
    return NEURAL_MODELS[arch](prep.vocab_size, prep.n_chars, len(NUM_FEATURES), **hparams)


def neural_predict(model, items, batch_size=8):
    """Returns per-document lists of predicted tag ids and probability matrices [n, 7]."""
    model.eval()
    preds, probs = [], []
    for s in range(0, len(items), batch_size):
        chunk = items[s:s + batch_size]
        batch = collate(chunk)
        p, pr = model.predict(batch)
        for b, it in enumerate(chunk):
            preds.append(p[b, :it["n"]].numpy())
            probs.append(pr[b, :it["n"]].numpy())
    return preds, probs


# --------------------------------------------------------------------------------------
# Evaluation
# --------------------------------------------------------------------------------------
def get_entities(tags):
    """conlleval-style span extraction from a BIO sequence -> set of (type, start, end)."""
    ents, cur = [], None
    for i, t in enumerate(list(tags) + ["O"]):
        if t == "O" or t.startswith("B-") or (t.startswith("I-") and (cur is None or cur[0] != t[2:])):
            if cur is not None:
                ents.append((cur[0], cur[1], i - 1))
                cur = None
            if t != "O":
                cur = (t[2:], i)
    return ents


def entity_scores(gold_docs, pred_docs):
    """Entity-level micro P/R/F1 (exact span + type match) overall and per entity type."""
    res = {}
    tp, npred, ngold = Counter(), Counter(), Counter()
    for g, p in zip(gold_docs, pred_docs):
        ge, pe = set(get_entities(g)), set(get_entities(p))
        for e in ge:
            ngold[e[0]] += 1
        for e in pe:
            npred[e[0]] += 1
        for e in ge & pe:
            tp[e[0]] += 1
    for t in ENTITY_TYPES + ["ALL"]:
        if t == "ALL":
            a, b, c = sum(tp.values()), sum(npred.values()), sum(ngold.values())
        else:
            a, b, c = tp[t], npred[t], ngold[t]
        p = a / b if b else 0.0
        r = a / c if c else 0.0
        res[t] = {"precision": p, "recall": r, "f1": 2 * p * r / (p + r) if p + r else 0.0, "support": c}
    return res


def bio_probs_to_class_probs(prob):
    """Aggregate 7 BIO probabilities into 4 word-level class probabilities (other, header, question, answer)."""
    return np.stack([prob[:, 0], prob[:, 1] + prob[:, 2], prob[:, 3] + prob[:, 4], prob[:, 5] + prob[:, 6]], 1)


def evaluate_model(gold_docs, pred_docs, prob_docs):
    """Word-level (4 classes) + entity-level metrics. gold/pred: lists of BIO tag lists per document."""
    from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                                 recall_score, roc_auc_score)
    yt = [bio_to_class(t) for d in gold_docs for t in d]
    yp = [bio_to_class(t) for d in pred_docs for t in d]
    P = np.concatenate([bio_probs_to_class_probs(p) for p in prob_docs])
    P = P / P.sum(1, keepdims=True)
    yt_idx = np.array([CLASS_NAMES.index(c) for c in yt])
    ent = entity_scores(gold_docs, pred_docs)
    return {
        "word_accuracy": accuracy_score(yt, yp),
        "word_precision_macro": precision_score(yt, yp, labels=CLASS_NAMES, average="macro", zero_division=0),
        "word_recall_macro": recall_score(yt, yp, labels=CLASS_NAMES, average="macro", zero_division=0),
        "word_f1_macro": f1_score(yt, yp, labels=CLASS_NAMES, average="macro", zero_division=0),
        "word_f1_weighted": f1_score(yt, yp, labels=CLASS_NAMES, average="weighted", zero_division=0),
        "roc_auc_ovr_macro": roc_auc_score(yt_idx, P, multi_class="ovr", average="macro", labels=list(range(4))),
        "entity_precision": ent["ALL"]["precision"], "entity_recall": ent["ALL"]["recall"],
        "entity_f1": ent["ALL"]["f1"],
        "entity_f1_header": ent["HEADER"]["f1"], "entity_f1_question": ent["QUESTION"]["f1"],
        "entity_f1_answer": ent["ANSWER"]["f1"],
        "confusion_matrix": confusion_matrix(yt, yp, labels=CLASS_NAMES).tolist(),
    }


# --------------------------------------------------------------------------------------
# Saved-model loading + end-to-end inference (used by the prediction notebook)
# --------------------------------------------------------------------------------------
def load_model_bundle(model_dir):
    """Load a saved model folder (sklearn / CRF / PyTorch) together with its preprocessing objects."""
    import joblib
    with open(os.path.join(model_dir, "config.json")) as f:
        cfg = json.load(f)
    bundle = {"config": cfg}
    if cfg["framework"] == "pytorch":
        prep = joblib.load(os.path.join(model_dir, "preprocessor.joblib"))
        model = build_neural_model(cfg["architecture"], prep, **cfg["hyperparameters"])
        model.load_state_dict(torch.load(os.path.join(model_dir, "model.pt"), map_location="cpu"))
        model.eval()
        bundle.update(model=model, preprocessor=prep)
    else:
        bundle["model"] = joblib.load(os.path.join(model_dir, cfg["model_file"]))
    return bundle


def predict_document(bundle, doc):
    """Run the classification stage on one preprocessed document -> (BIO tags, prob matrix [n,7])."""
    cfg = bundle["config"]
    if cfg["framework"] == "pytorch":
        item = bundle["preprocessor"].transform(doc)
        p, pr = neural_predict(bundle["model"], [item])
        return [ID2LABEL[int(i)] for i in p[0]], pr[0]
    feats = classical_features(doc)
    if cfg["framework"] == "sklearn-crfsuite":
        m = bundle["model"]
        tags = m.predict_single(feats)
        marg = m.predict_marginals_single(feats)
        pr = np.array([[mg.get(l, 0.0) for l in BIO_LABELS] for mg in marg])
        return list(tags), pr
    m = bundle["model"]
    pr_raw = m.predict_proba(feats)
    pr = np.zeros((len(feats), len(BIO_LABELS)))
    for j, c in enumerate(m.classes_):
        pr[:, LABEL2ID[c]] = pr_raw[:, j]
    return [BIO_LABELS[i] for i in pr.argmax(1)], pr


def group_entities(doc, tags, probs):
    """Extraction stage: merge BIO-tagged words into entities with text, box and mean confidence."""
    out = []
    for t, s, e in get_entities(tags):
        ws = doc["words"][s:e + 1]
        conf = float(np.mean([probs[i].max() for i in range(s, e + 1)]))
        out.append({"label": t.lower(), "text": " ".join(w["text"] for w in ws),
                    "box": [min(w["box"][0] for w in ws), min(w["box"][1] for w in ws),
                            max(w["box"][2] for w in ws), max(w["box"][3] for w in ws)],
                    "confidence": round(conf, 4), "word_span": [s, e]})
    return out


def link_key_values(entities, max_dy_ratio=3.0):
    """Rule-based post-processing (not a learned model): pair each ANSWER with the nearest QUESTION
    on the same line to its left, otherwise the nearest QUESTION directly above it."""
    qs = [e for e in entities if e["label"] == "question"]
    pairs = []
    for a in (e for e in entities if e["label"] == "answer"):
        ax0, ay0, ax1, ay1 = a["box"]
        ah = ay1 - ay0
        best, best_d = None, 1e9
        for q in qs:
            qx0, qy0, qx1, qy1 = q["box"]
            same_line = min(ay1, qy1) - max(ay0, qy0) > 0.4 * min(ah, qy1 - qy0)
            if same_line and qx1 <= ax0 + 5:
                d = ax0 - qx1
            elif qy1 <= ay0 + 2 and (ay0 - qy1) < max_dy_ratio * ah and min(ax1, qx1) - max(ax0, qx0) > 0:
                d = 1000 + (ay0 - qy1)
            else:
                continue
            if d < best_d:
                best, best_d = q, d
        if best is not None:
            pairs.append({"question": best["text"], "answer": a["text"],
                          "confidence": round(min(best["confidence"], a["confidence"]), 4)})
    return pairs


def process_document(bundle, doc, low_conf_threshold=0.6):
    """Full IDP pipeline on one document: classification -> extraction -> validation -> structured output."""
    t0 = time.perf_counter()
    tags, probs = predict_document(bundle, doc)
    elapsed = time.perf_counter() - t0
    ents = group_entities(doc, tags, probs)
    words = [{"text": w["text"], "box": w["box"], "predicted_tag": t, "predicted_class": bio_to_class(t),
              "confidence": round(float(probs[i].max()), 4)} for i, (w, t) in enumerate(zip(doc["words"], tags))]
    return {"doc_id": doc["doc_id"], "model": bundle["config"]["model_name"],
            "processing_time_sec": round(elapsed, 4), "n_words": len(words), "words": words,
            "entities": ents, "key_value_pairs": link_key_values(ents),
            "low_confidence_entities": [e for e in ents if e["confidence"] < low_conf_threshold]}
