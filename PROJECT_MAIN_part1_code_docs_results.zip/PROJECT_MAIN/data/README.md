# Data

## Dataset: FUNSD (Form Understanding in Noisy Scanned Documents)

- Source: https://guillaumejaume.github.io/FUNSD/ (official `dataset.zip`, obtained from the author's repository
  `github.com/GuillaumeJaume/FUNSD`, which hosts that website)
- Reference: Jaume, Ekenel, Thiran, "FUNSD: A Dataset for Form Understanding in Noisy Scanned Documents", ICDAR-OST 2019
- 199 real scanned forms (149 train / 50 test), grey-scale PNG + JSON annotations
- Each annotation lists entities (`header`, `question`, `answer`, `other`) with box, words (text + box) and question-answer links
- License: for non-commercial, research and educational use only (see the FUNSD website)

## Folders

| Folder | Contents |
|---|---|
| `raw/dataset/training_data/{images,annotations}` | 149 original training forms |
| `raw/dataset/testing_data/{images,annotations}` | 50 original test forms |
| `processed/funsd_{train,val,test}_words.csv` | Cleaned word-level tables in reading order with BIO tags and engineered numeric features (written by notebook 01) |
| `processed/split_doc_ids.json` | Document ids of the train / validation / test split |
| `processed/predictions/` | JSON outputs written by notebook 02 |
| `sample_input/` | Sample new input for notebook 02: test form `82092117.png` and its words/boxes with all labels removed (`82092117_words.json`) |

## Preprocessing summary

1. Empty or whitespace-only OCR words are removed (624 in train, 266 in test); boxes are clipped to the page.
2. Words are put in geometric reading order (grouped into text lines, top to bottom, then left to right). Only geometry is used, never the annotation order or entity ids.
3. Gold BIO tags (`B-/I-` + `HEADER/QUESTION/ANSWER`, `O` for `other`) are derived in that reading order.
4. A validation split (15% of training documents, seed 42) is held out for model selection. The official test split is used only for final evaluation.
